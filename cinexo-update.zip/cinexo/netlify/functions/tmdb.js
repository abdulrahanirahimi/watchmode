// Proxy naar TMDB. De API-key staat alleen op de server (Netlify env var TMDB_API_KEY)
// en komt nooit in de browser terecht.
const ALLOWED = /^(trending\/(movie|tv|all)\/(day|week)|(movie|tv)\/(top_rated|popular|now_playing|upcoming|on_the_air|airing_today)|(movie|tv)\/\d+(\/(credits|recommendations|videos|external_ids|watch\/providers|season\/\d+))?|search\/(movie|tv|multi)|discover\/(movie|tv)|genre\/(movie|tv)\/list)$/;

export default async (req) => {
  const key = process.env.TMDB_API_KEY;
  if (!key) return json({ error: 'TMDB_API_KEY ontbreekt op de server' }, 500);

  const url = new URL(req.url);
  const path = (url.searchParams.get('path') || '').replace(/^\/+/, '');
  if (!ALLOWED.test(path)) return json({ error: 'Pad niet toegestaan' }, 400);

  const params = new URLSearchParams();
  for (const [k, v] of url.searchParams) {
    if (k !== 'path' && k !== 'api_key') params.set(k, v);
  }
  if (!params.has('language')) params.set('language', 'nl-NL');
  params.set('api_key', key);

  const res = await fetch(`https://api.themoviedb.org/3/${path}?${params}`);
  const body = await res.text();
  return new Response(body, {
    status: res.status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      // Cache bij de browser en Netlify's CDN, zodat je minder API-calls doet
      'cache-control': 'public, max-age=600, s-maxage=3600',
    },
  });
};

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8' },
  });
}
