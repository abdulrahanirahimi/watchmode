// Proxy naar OMDb voor IMDb-, Rotten Tomatoes- en Metacritic-scores.
// Key staat op de server (Netlify env var OMDB_API_KEY). Gratis key: https://www.omdbapi.com/apikey.aspx
export default async (req) => {
  const key = process.env.OMDB_API_KEY;
  if (!key) return json({ Response: 'False', Error: 'OMDB_API_KEY ontbreekt' }, 200);

  const imdb = new URL(req.url).searchParams.get('i') || '';
  if (!/^tt\d{5,10}$/.test(imdb)) return json({ Response: 'False', Error: 'Ongeldig IMDb-id' }, 400);

  const res = await fetch(`https://www.omdbapi.com/?i=${imdb}&apikey=${encodeURIComponent(key)}`);
  const body = await res.text();
  return new Response(body, {
    status: res.status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'public, max-age=86400, s-maxage=86400',
    },
  });
};

function json(obj, status) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8' },
  });
}
