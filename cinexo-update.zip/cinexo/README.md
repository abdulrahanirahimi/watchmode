# Cinexo

Films, series en anime ontdekken met TMDB-data, trailers, IMDb/Rotten Tomatoes-scores en "waar te kijken in Nederland".

## API-keys (staan NIET meer in de code)

De keys staan alleen op de server, in Netlify-omgevingsvariabelen. De browser praat met `/api/tmdb` en `/api/omdb` (Netlify Functions), die de key er zelf aan toevoegen.

| Variabele | Waarvoor | Gratis key |
|---|---|---|
| `TMDB_API_KEY` | Films/series, posters, trailers, waar te kijken | https://www.themoviedb.org/settings/api |
| `OMDB_API_KEY` | IMDb-, Rotten Tomatoes- en Metacritic-scores (optioneel) | https://www.omdbapi.com/apikey.aspx |

Instellen: Netlify → je site → **Site configuration → Environment variables** → beide toevoegen → opnieuw deployen.

Lokaal testen: kopieer `.env.example` naar `.env`, vul de keys in en draai `npx netlify dev`. `.env` wordt nooit gecommit (staat in `.gitignore`).

## Bestanden

- `index.html` — de site
- `netlify/functions/tmdb.js` — TMDB-proxy (alleen toegestane paden, met caching)
- `netlify/functions/omdb.js` — OMDb-proxy
- `netlify.toml` — build + `/api/*` routes
